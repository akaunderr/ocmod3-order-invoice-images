<?php

//  * Order Invoice - Images v1.0 (https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id=<EXTENSION_ID>)
//  * Copyright 2018 Andrii Burkatskyi aka underr
//  * Licensed under MIT - https://raw.githubusercontent.com/underr-ua/ocmod3-order-invoice-images/master/LICENSE.txt

// Order Invoice - Images heading
$_['heading_title']     = '[underr] Order Invoice - Images';

// Order Invoice - Images error text
$_['error_permission']  = 'Warning: You do not have permission to modify Order Invoice - Images!';

// Order Invoice - Images entry text
$_['entry_status']      = 'Status';
$_['entry_width']       = 'Image width';

// Order Invoice - Images help text

// Order Invoice - Images main text
$_['text_extension']    = 'Extensions';
$_['text_success']      = 'Success: Order Invoice - Images configured!';
$_['text_edit']         = 'Edit Order Invoice - Images';

