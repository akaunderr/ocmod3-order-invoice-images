<?php

//  * Order Invoice - Images v1.0 - https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id=35204
//  * Copyright 2018 Andrii Burkatskyi aka underr
//  * Licensed under MIT - https://raw.githubusercontent.com/underr-ua/ocmod3-order-invoice-images/master/LICENSE.txt

// Order Invoice - Images heading
$_['heading_title']     = '[underr] Order Invoice - Images';

// Order Invoice - Images Error text
$_['error_permission']  = 'Увага: Недостатньо прав для зміни налаштувань Order Invoice - Images!';

// Order Invoice - Images Entry text
$_['entry_status']      = 'Статус';
$_['entry_width']       = 'Ширина зображення';

// Order Invoice - Images help text

// Order Invoice - Images main text
$_['text_extension']    = 'Розширення';
$_['text_success']      = 'Order Invoice - Images настроєно успішно!';
$_['text_edit']         = 'Налаштування Order Invoice - Images';

